package com.mydata.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.mydata.model.TodoAppRegister;
import com.mydata.util.CreateConnection;

public class TodoAppRegisterDaoImpl implements TodoAppRegisterDao
{
	Connection con=CreateConnection.initConnection();

	@Override
	public int saveuser(TodoAppRegister tr) {
		int x=0;
		
		try 
		{
			PreparedStatement ps=con.prepareStatement("insert into todoapp value(?,?,?,?)");
			ps.setString(1, tr.getFname());
			ps.setString(2, tr.getLname());
			ps.setString(3, tr.getUname());
			ps.setString(4, tr.getPass());
			
			x=ps.executeUpdate();
			con.close();
		} 
		catch (Exception e) 
		{
			System.out.println(e);
		}
		
		return x;
	}
}

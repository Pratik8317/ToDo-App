package com.mydata.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.mydata.model.AddTodo;
import com.mydata.util.CreateConnection;

public class TodoDaoImpl implements TodoDao
{
	Connection con=CreateConnection.initConnection();
	@Override
	public int addTodo(AddTodo at) {
		int x=0;
		
		try 
		{
			PreparedStatement ps=con.prepareStatement("insert into todolisttry value(?,?,?,?)");
			ps.setString(1, at.getTitle());
			ps.setString(2, at.getDiscription());
			ps.setString(3, at.getStatus());
			ps.setString(4, at.getDate());
			
			x=ps.executeUpdate();
		} 
		catch (Exception e) 
		{
			System.out.println(e);
		}
		
		return x;
	}
	@Override
	public List<AddTodo> viewAllTodo() {
		List<AddTodo> all=new ArrayList<>();
		try 
		{
			PreparedStatement ps=con.prepareStatement("select * from todolisttry");
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				AddTodo ad=new AddTodo();
				ad.setTitle(rs.getString(1));
				ad.setDiscription(rs.getString(2));
				ad.setStatus(rs.getString(3));
				ad.setDate(rs.getString(4));
				
				all.add(ad);
			}
		} 
		catch (Exception e) 
		{
			System.out.println(e);
		}
		return all;
	}
	@Override
	public String updateTodo(String title, String status) {
		String res="success";
		try 
		{
		    PreparedStatement ps=con.prepareStatement("update todolisttry set Status=? where Title=?")	;
		    ps.setString(1, status);
		    ps.setString(2, title);
		    int x = ps.executeUpdate(); 
	        if (x > 0) {
	            res = "success";
	        } else {
	            res = "fail"; 
	        } 
		} 
		catch (Exception e) 
		{
			System.out.println(e);
		}
		
		return res;
	}
	@Override
	public String delete(String title) {
		
		try 
		{
			PreparedStatement ps=con.prepareStatement("delete from todolisttry where Title=?");
			ps.setString(1, title);
			int x=ps.executeUpdate();
			
		} catch (Exception e) 
		{
			System.out.println(e);
		}
		return "";
	}
	@Override
	public AddTodo viewByTitle(String title) {
		AddTodo at=new AddTodo();
		try 
		{
			PreparedStatement ps=con.prepareStatement("select * from Todolisttry where Title=?");
			ps.setString(1, title);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				at.setTitle(rs.getString(1));
				at.setDiscription(rs.getString(2));
				at.setStatus(rs.getString(3));
				at.setDate(rs.getString(4));
			}
		}
		catch (Exception e) 
		{
			System.out.println(e);
		}
		return at;
	}

}

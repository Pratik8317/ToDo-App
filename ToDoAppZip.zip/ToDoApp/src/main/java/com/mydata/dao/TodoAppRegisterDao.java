package com.mydata.dao;

import com.mydata.model.TodoAppRegister;

public interface TodoAppRegisterDao {
	public int saveuser(TodoAppRegister tr);
}

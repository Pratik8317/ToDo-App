package com.mydata.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.print.attribute.standard.RequestingUserName;

import com.mydata.model.TodoAppLogin;
import com.mydata.util.CreateConnection;

public class TodoAppLoginDaoImpl implements TodoAppLoginDao
{
	Connection con=CreateConnection.initConnection();
	@Override
	public String validLogin(TodoAppLogin ta) 
	{
		String res=null;
		String entuser=ta.getUsername();
		String entpass=ta.getPassword();
		String dbpass=null;
		
		try 
		{
			PreparedStatement ps=con.prepareStatement("select password from todoapp where username=?");
			ps.setString(1, entuser);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				dbpass=rs.getString("password");
			}
			con.close();
		} 
		catch (Exception e) 
		{
			System.out.println(e);
		}
		if(entpass.equals(dbpass))
		{
			res="valid";
		}
		else
		{
			res="invalid";
		}
		return res;
	}

}

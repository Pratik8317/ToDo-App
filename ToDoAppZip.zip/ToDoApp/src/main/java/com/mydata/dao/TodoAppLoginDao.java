package com.mydata.dao;

import com.mydata.model.TodoAppLogin;

public interface TodoAppLoginDao 
{
	public String validLogin(TodoAppLogin ta);
}

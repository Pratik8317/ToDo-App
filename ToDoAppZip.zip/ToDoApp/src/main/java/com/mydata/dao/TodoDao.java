package com.mydata.dao;

import java.util.List;

import com.mydata.model.AddTodo;

public interface TodoDao  
{
		public int addTodo(AddTodo at);
		public List<AddTodo> viewAllTodo();
		public String updateTodo(String title, String status);
		public String delete(String title);
		public AddTodo viewByTitle(String title);
}

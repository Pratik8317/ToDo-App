package com.mydata.model;

import java.io.Serializable;

public class TodoAppLogin implements Serializable
{
	private String username;
	private String password;
	
	public TodoAppLogin(String username, String password) {
		super();
		this.username = username;
		this.password = password;
	}
	
	public TodoAppLogin() {}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "TodoAppLogin [username=" + username + ", password=" + password + "]";
	}
	
	
}

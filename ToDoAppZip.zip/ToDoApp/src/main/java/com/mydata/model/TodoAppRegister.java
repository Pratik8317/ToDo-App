package com.mydata.model;

import java.io.Serializable;

public class TodoAppRegister implements Serializable
{
	private String fname;
	private String lname;
	private String uname;
	private String Pass;
	public TodoAppRegister(String fname, String lname, String uname, String pass) {
		super();
		this.fname = fname;
		this.lname = lname;
		this.uname = uname;
		this.Pass = pass;
	}
	public TodoAppRegister() {}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getPass() {
		return Pass;
	}
	public void setPass(String pass) {
		Pass = pass;
	}
	@Override
	public String toString() {
		return "TodoAppRegister [fname=" + fname + ", lname=" + lname + ", uname=" + uname + ", Pass=" + Pass + "]";
	}
	
	
}

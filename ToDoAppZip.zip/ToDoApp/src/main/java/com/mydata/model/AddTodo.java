package com.mydata.model;

import java.io.Serializable;
import java.time.LocalDate;
public class AddTodo implements Serializable
{
	private String title;
	private String discription;
	private String status;
	private String date;
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDiscription() {
		return discription;
	}
	public void setDiscription(String discription) {
		this.discription = discription;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getDate() {
	    return date;
	}
	
	public void setDate(String date) {
		this.date = date;
	}
	public AddTodo(String title, String discription, String status, String date) {
		super();
		this.title = title;
		this.discription = discription;
		this.status = status;
		this.date = date;
	}
	public AddTodo(String title, String status) {
		super();
		this.title = title;
		
		this.status = status;
		
	}
	public AddTodo() {}
	@Override
	public String toString() {
		return title + " " + discription + " " + status + " " + date;
	}
	
}

package com.mydata.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mydata.dao.TodoAppRegisterDao;
import com.mydata.dao.TodoAppRegisterDaoImpl;
import com.mydata.model.TodoAppRegister;

/**
 * Servlet implementation class TodoAppRegisterController
 */
public class TodoAppRegisterController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TodoAppRegisterController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		String fn=request.getParameter("fsname");
		String ln=request.getParameter("lsname");
		String un=request.getParameter("usname");
		String pwd=request.getParameter("spass");
		
		TodoAppRegister tsar=new TodoAppRegister(fn, ln, un, pwd);
		TodoAppRegisterDao tdard=new TodoAppRegisterDaoImpl();
		
		int res=tdard.saveuser(tsar);
		if(res>0)
		{
			request.getRequestDispatcher("index.html").forward(request, response);
		}
		else
		{
			out.print("Try Again...!");
			request.getRequestDispatcher("register.html").include(request, response);
		}
	}
}

package com.mydata.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mydata.dao.TodoDao;
import com.mydata.dao.TodoDaoImpl;
import com.mydata.model.AddTodo;

/**
 * Servlet implementation class AddNewTodoServlet
 */
public class AddNewTodoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddNewTodoServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/jsp");
		PrintWriter out =response.getWriter();
		
		String title=request.getParameter("ttitle");
		String discription=request.getParameter("tdisc");
		String status=request.getParameter("tstatus");
		String tdateString = request.getParameter("tdate");
		
				
		AddTodo at=new AddTodo(title, discription, status, tdateString);
		TodoDao td=new TodoDaoImpl();
		
		int res=td.addTodo(at);
		
		if(res>0)
		{
			request.getRequestDispatcher("ListofTodo.jsp").forward(request, response);
		}
		else
		{
			out.print("Try Again...");
			request.getRequestDispatcher("AddNewTodo.jsp").include(request, response);
		}
	}

}

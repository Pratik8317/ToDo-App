package com.mydata.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mydata.dao.TodoDao;
import com.mydata.dao.TodoDaoImpl;
import com.mydata.model.AddTodo;

/**
 * Servlet implementation class UpdateServlet
 */
@SuppressWarnings("serial")
public class UpdateServlet extends HttpServlet {
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		String title=request.getParameter("title");
		String des=request.getParameter("discription");
		String status=request.getParameter("status");
		String d=request.getParameter("date");
		//System.out.println(title+""+status);
		
	TodoDao td=new TodoDaoImpl();
	String res=td.updateTodo(title, status);
	//System.out.println(title+""+status);
	if (res != null)
	{
		request.getRequestDispatcher("ListofTodo.jsp").forward(request, response);
	}
		else
		{
			out.print("<h2>Try Again...</h2>");
			request.getRequestDispatcher("UpdateTodo.jsp").include(request, response);
		}
	System.out.println("Title: " + title + " Description: " + des + " Status: " + status + " Date: " + d);

	}

}
